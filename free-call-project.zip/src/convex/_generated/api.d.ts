/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as admin from "../admin.js";
import type * as adminConfig from "../adminConfig.js";
import type * as auth from "../auth.js";
import type * as auth_emailOtp from "../auth/emailOtp.js";
import type * as calls from "../calls.js";
import type * as conversations from "../conversations.js";
import type * as groupCalls from "../groupCalls.js";
import type * as groups from "../groups.js";
import type * as http from "../http.js";
import type * as messages from "../messages.js";
import type * as notifications from "../notifications.js";
import type * as presence from "../presence.js";
import type * as turn from "../turn.js";
import type * as users from "../users.js";
import type * as webPush from "../webPush.js";
import type * as webPushSender from "../webPushSender.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  admin: typeof admin;
  adminConfig: typeof adminConfig;
  auth: typeof auth;
  "auth/emailOtp": typeof auth_emailOtp;
  calls: typeof calls;
  conversations: typeof conversations;
  groupCalls: typeof groupCalls;
  groups: typeof groups;
  http: typeof http;
  messages: typeof messages;
  notifications: typeof notifications;
  presence: typeof presence;
  turn: typeof turn;
  users: typeof users;
  webPush: typeof webPush;
  webPushSender: typeof webPushSender;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
